package com.example.projetoaplicado

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
